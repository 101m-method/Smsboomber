# sms


pip install upgrade

pip install update

pip install python

pip install phonenumbers

pip install requests

pip install git

cd sms

python smsat.py
